import math

def power_scale(
    count: int,
    min_val: int = 3,
    max_val: int = 15,
    max_count: int = 35000,
    power: float = 0.5,
) -> int:
    if count <= 0:
        return min_val
    progress = (count / max_count) ** power
    return int(round(min(max_val, min_val + (max_val - min_val) * progress)))


def log_scale(
    count: int,
    min_val: int = 3,
    max_val: int = 15,
    max_count: int = 28000,
) -> int:
    if count <= 0:
        return min_val
    progress = math.log(1 + count) / math.log(1 + max_count)
    return int(round(min(max_val, min_val + (max_val - min_val) * progress)))
